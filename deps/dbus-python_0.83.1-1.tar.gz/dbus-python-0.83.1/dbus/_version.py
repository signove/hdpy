# dbus/_version.py.  Generated from _version.py.in by configure.
version = (0, 83, 1)
__version__ = "0.83.1"
